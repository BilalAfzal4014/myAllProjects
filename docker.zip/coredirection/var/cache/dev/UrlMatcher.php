<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/admin' => [[['_route' => 'sonata_admin_redirect', '_controller' => 'Symfony\\Bundle\\FrameworkBundle\\Controller\\RedirectController::redirectAction', 'route' => 'sonata_admin_dashboard', 'permanent' => 'true'], null, null, null, true, false, null]],
        '/admin/dashboard' => [[['_route' => 'sonata_admin_dashboard', '_controller' => 'Sonata\\AdminBundle\\Action\\DashboardAction'], null, null, null, false, false, null]],
        '/admin/core/get-form-field-element' => [[['_route' => 'sonata_admin_retrieve_form_element', '_controller' => 'sonata.admin.action.retrieve_form_field_element'], null, null, null, false, false, null]],
        '/admin/core/append-form-field-element' => [[['_route' => 'sonata_admin_append_form_element', '_controller' => 'sonata.admin.action.append_form_field_element'], null, null, null, false, false, null]],
        '/admin/core/set-object-field-value' => [[['_route' => 'sonata_admin_set_object_field_value', '_controller' => 'sonata.admin.action.set_object_field_value'], null, null, null, false, false, null]],
        '/admin/search' => [[['_route' => 'sonata_admin_search', '_controller' => 'Sonata\\AdminBundle\\Action\\SearchAction'], null, null, null, false, false, null]],
        '/admin/core/get-autocomplete-items' => [[['_route' => 'sonata_admin_retrieve_autocomplete_items', '_controller' => 'sonata.admin.action.retrieve_autocomplete_items'], null, null, null, false, false, null]],
        '/admin/sonata/user/user/list' => [[['_route' => 'admin_sonata_user_user_list', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction', '_sonata_admin' => 'sonata.user.admin.user', '_sonata_name' => 'admin_sonata_user_user_list'], null, null, null, false, false, null]],
        '/admin/sonata/user/user/create' => [[['_route' => 'admin_sonata_user_user_create', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction', '_sonata_admin' => 'sonata.user.admin.user', '_sonata_name' => 'admin_sonata_user_user_create'], null, null, null, false, false, null]],
        '/admin/sonata/user/user/batch' => [[['_route' => 'admin_sonata_user_user_batch', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction', '_sonata_admin' => 'sonata.user.admin.user', '_sonata_name' => 'admin_sonata_user_user_batch'], null, null, null, false, false, null]],
        '/admin/sonata/user/user/export' => [[['_route' => 'admin_sonata_user_user_export', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction', '_sonata_admin' => 'sonata.user.admin.user', '_sonata_name' => 'admin_sonata_user_user_export'], null, null, null, false, false, null]],
        '/admin/sonata/user/group/list' => [[['_route' => 'admin_sonata_user_group_list', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction', '_sonata_admin' => 'sonata.user.admin.group', '_sonata_name' => 'admin_sonata_user_group_list'], null, null, null, false, false, null]],
        '/admin/sonata/user/group/create' => [[['_route' => 'admin_sonata_user_group_create', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction', '_sonata_admin' => 'sonata.user.admin.group', '_sonata_name' => 'admin_sonata_user_group_create'], null, null, null, false, false, null]],
        '/admin/sonata/user/group/batch' => [[['_route' => 'admin_sonata_user_group_batch', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction', '_sonata_admin' => 'sonata.user.admin.group', '_sonata_name' => 'admin_sonata_user_group_batch'], null, null, null, false, false, null]],
        '/admin/sonata/user/group/export' => [[['_route' => 'admin_sonata_user_group_export', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction', '_sonata_admin' => 'sonata.user.admin.group', '_sonata_name' => 'admin_sonata_user_group_export'], null, null, null, false, false, null]],
        '/admin/login' => [[['_route' => 'sonata_user_admin_security_login', '_controller' => 'Sonata\\UserBundle\\Action\\LoginAction'], null, null, null, false, false, null]],
        '/admin/login_check' => [[['_route' => 'sonata_user_admin_security_check', '_controller' => 'Sonata\\UserBundle\\Action\\CheckLoginAction'], null, ['POST' => 0], null, false, false, null]],
        '/admin/logout' => [[['_route' => 'sonata_user_admin_security_logout', '_controller' => 'Sonata\\UserBundle\\Action\\LogoutAction'], null, null, null, false, false, null]],
        '/admin/resetting/request' => [[['_route' => 'sonata_user_admin_resetting_request', '_controller' => 'Sonata\\UserBundle\\Action\\RequestAction'], null, ['GET' => 0], null, false, false, null]],
        '/admin/resetting/send-email' => [[['_route' => 'sonata_user_admin_resetting_send_email', '_controller' => 'Sonata\\UserBundle\\Action\\SendEmailAction'], null, ['POST' => 0], null, false, false, null]],
        '/admin/resetting/check-email' => [[['_route' => 'sonata_user_admin_resetting_check_email', '_controller' => 'Sonata\\UserBundle\\Action\\CheckEmailAction'], null, ['GET' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/admin/(?'
                    .'|core/get\\-short\\-object\\-description(?:\\.(html|json))?(*:233)'
                    .'|sonata/user/(?'
                        .'|user/([^/]++)/(?'
                            .'|edit(*:277)'
                            .'|delete(*:291)'
                            .'|show(*:303)'
                        .')'
                        .'|group/([^/]++)/(?'
                            .'|edit(*:334)'
                            .'|delete(*:348)'
                            .'|show(*:360)'
                        .')'
                    .')'
                    .'|resetting/reset/([^/]++)(*:394)'
                .')'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        233 => [[['_route' => 'sonata_admin_short_object_information', '_controller' => 'sonata.admin.action.get_short_object_description', '_format' => 'html'], ['_format'], null, null, false, true, null]],
        277 => [[['_route' => 'admin_sonata_user_user_edit', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction', '_sonata_admin' => 'sonata.user.admin.user', '_sonata_name' => 'admin_sonata_user_user_edit'], ['id'], null, null, false, false, null]],
        291 => [[['_route' => 'admin_sonata_user_user_delete', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction', '_sonata_admin' => 'sonata.user.admin.user', '_sonata_name' => 'admin_sonata_user_user_delete'], ['id'], null, null, false, false, null]],
        303 => [[['_route' => 'admin_sonata_user_user_show', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction', '_sonata_admin' => 'sonata.user.admin.user', '_sonata_name' => 'admin_sonata_user_user_show'], ['id'], null, null, false, false, null]],
        334 => [[['_route' => 'admin_sonata_user_group_edit', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction', '_sonata_admin' => 'sonata.user.admin.group', '_sonata_name' => 'admin_sonata_user_group_edit'], ['id'], null, null, false, false, null]],
        348 => [[['_route' => 'admin_sonata_user_group_delete', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction', '_sonata_admin' => 'sonata.user.admin.group', '_sonata_name' => 'admin_sonata_user_group_delete'], ['id'], null, null, false, false, null]],
        360 => [[['_route' => 'admin_sonata_user_group_show', '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction', '_sonata_admin' => 'sonata.user.admin.group', '_sonata_name' => 'admin_sonata_user_group_show'], ['id'], null, null, false, false, null]],
        394 => [
            [['_route' => 'sonata_user_admin_resetting_reset', '_controller' => 'Sonata\\UserBundle\\Action\\ResetAction'], ['token'], ['GET' => 0, 'POST' => 1], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
