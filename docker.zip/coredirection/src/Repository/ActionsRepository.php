<?php


namespace App\Repository;


class ActionsRepository extends  BaseRepository
{


}