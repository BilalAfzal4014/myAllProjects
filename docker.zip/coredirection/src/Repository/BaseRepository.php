<?php


namespace App\Repository;


class BaseRepository
{

}