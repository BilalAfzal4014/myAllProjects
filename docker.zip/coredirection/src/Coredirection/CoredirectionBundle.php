<?php


namespace App\Coredirection;


use Symfony\Component\HttpKernel\Bundle\Bundle;

class CoredirectionBundle extends Bundle
{

}