<?php

namespace App\Gamification\Bundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GamificationBundle extends Bundle
{
}
