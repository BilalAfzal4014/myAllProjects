const _ = require("lodash");
const BaseUseCase = require("../../base/base-usecase");
const ErrorTypes = require("../../../errors/error-types");
const Validator = require("../../../entity-validations/validator");
const RefreshTokenEntity = require("../../../entities/refresh-token/refresh-token-entity");
const GeneralHelper = require("../../../helpers/general-helper");
const FosUserUserRepo = require("../../../repositories/fosUserUserRepo");
const RefreshTokensRepo = require("../../../repositories/refreshTokensRepo");

module.exports = class RefreshTokenUseCase extends BaseUseCase {
    constructor(payLoad) {
        super();
        this.payLoad = payLoad;
        this.refreshTokenEntityInstance = new RefreshTokenEntity();
        this.token = null;
        this.validatorInstance = null;
    }

    getJwtToken() {
        return this.validate()
            .then(() => {
                this.performQuery2()
                    .then((records) => {
                        console.log('records', records)
                        return records.length ? console.log('record exisstsss') : console.log('no record exisst');
                    }).catch((error) => {
                    console.log('error')
                    // return error instanceof Error ? Promise.reject(error) : error
                });
            })
    }
    performQuery1() {
        return RefreshTokensRepo.findByAttributes(this.payLoad.refresh_token)
    }
    performQuery2() {
        return FosUserUserRepo.findByAttributes([], [{key: "username", value: "Clifford_Tindell"}], false)
    }

    validate() {
        return this.validateUserProvidedFieldsForRefreshToken()
            .then((errorsList) => {
                this.sendErrorIfAnyForValidation(errorsList);
            });
    }

    validateUserProvidedFieldsForRefreshToken() {
        this.payLoad = _.pick(this.payLoad, this.refreshTokenEntityInstance.getUserProvidedFields());
        this.validatorInstance = new Validator(this.payLoad, FosUserUserRepo);
        return this.validatorInstance.validate(
            this.refreshTokenEntityInstance.getValidationRules(),
            this.refreshTokenEntityInstance.getFieldsForUniqueness()
        );
    }

    sendErrorIfAnyForValidation(errorList) {
        this.handleErrorIfExist(errorList,
            ErrorTypes.NOT_FOUND,
            "Refresh Token Validation failed",
            "Refresh token from validation function in RefreshTokenUseCase"
        );
    }

    findUserByEmailAndMemberGroup() {
        return FosUserUserGroupRepo.findUserBelongsToParticularGroup(this.payLoad.email, FosUserGroupConstants.MEMBER)
            .then((user) => {
                if (user)
                    return this.user = user;
            });
    }
}