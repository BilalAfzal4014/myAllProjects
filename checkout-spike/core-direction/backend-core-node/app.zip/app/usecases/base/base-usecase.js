const BusinessError = require('../../errors/business-error');
const BaseRepo = require("../../repositories/baseRepo");
const {v4: uuid} = require("uuid");
const BcryptHelper = require("../../helpers/bcrypt-helper");

module.exports = class BaseUseCase {

    constructor(transaction = null) {
        this.transactionInstance = transaction;
    }

    getTransactionInstance() {
        return BaseRepo.startTransaction()
            .then((transaction) => {
                return this.transactionInstance = transaction;
            });
    }

    commitTransaction() {
        return BaseRepo.commitTransaction(this.transactionInstance);
    }

    rollbackTransaction() {
        return BaseRepo.rollbackTransaction(this.transactionInstance);
    }


    handleErrorIfExist(errorsList, errorType, message, location) {
        if (this.hasError(errorsList)) {
            this.handleError(
                errorsList,
                errorType,
                message,
                location
            );
        }
    }

    hasError(errorsList) {
        return errorsList.length > 0;
    }

    handleError(errorsList, errorType, message, location) {
        throw new BusinessError(
            errorType,
            message,
            errorsList,
            location
        );
    }

    generateUserDataToSave(payLoad) {
        return {
            username: payLoad.email,
            username_canonical: payLoad.email,
            email: payLoad.email,
            email_canonical: payLoad.email,
            enabled: 0,
            salt: 10,
            roles:'a:0:{}',
            password: payLoad.password,
            confirmation_token: this.generateToken(),
            phone: payLoad.phone_number,
            is_gdpr: 1
        }


    }

    convertPasswordToHash(password) {

        return this.updatePasswordToBcryptIt(password).then((password) => {
            return password;
        })
    }

    generateToken() {
        return uuid();
    }
}