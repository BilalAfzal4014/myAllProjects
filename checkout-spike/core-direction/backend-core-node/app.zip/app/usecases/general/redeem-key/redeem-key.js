const BaseUseCase = require("../../base/base-usecase");
const MemberKeyRepo = require("../../../repositories/memberKeyRepo");
const GeneralHelper = require("../../../helpers/general-helper");
const CorporateKey = require("../../../constants/corporate-key");
const PackageRepo = require("../../../repositories/packageRepo");
const MemberPackageRepo = require("../../../repositories/memberPackageRepo");

module.exports = class RedeemKeyUseCase extends BaseUseCase {


    constructor(corporateKey) {
        super();
        this.user = null;
        this.corporateKey = corporateKey;
    }

    redeemProcess(user,transactionInstance) {

        this.user = user;
        this.transactionInstance = transactionInstance;
        return Promise.all([

            this.entryInMemberKeyTable(),
            this.redeemPackagesAgainstKey()
        ]);
    }


    entryInMemberKeyTable() {
        return MemberKeyRepo.save(
            {
                member_id: this.user,
                key_id: this.corporateKey.id,
                created: GeneralHelper.addXMinutesToCurrentDateTime(1)
            }, this.transactionInstance
        )

    }

    redeemPackagesAgainstKey() {


        if (this.corporateKey.type === CorporateKey.PACKAGE || this.corporateKey.type === CorporateKey.COREPASS) {

            return this.getPackagesAgainstKey()
                .then((packages) => {
                    return this.addPackagesToUserWallet(packages)
                });
        }else{

            return Promise.resolve([]);
        }


    }

    getPackagesAgainstKey() {

        return PackageRepo.findByFacilityId(this.corporateKey.corporate_id);
    }

    addPackagesToUserWallet(packages) {

        let memberPackageArr = [];
        packages.forEach((packageToRedeem) => {
            let memberPackage = this.addPackageToUserWallet(packageToRedeem.id);
            memberPackageArr.push(memberPackage)
        })
        return Promise.all(memberPackageArr)
    }




    addPackageToUserWallet(packageId){


        return MemberPackageRepo.save({
            package_id:packageId,
            checkin:0,
            status:'active',
            is_promotion:false,
            modifiedby: this.user,
            member_id: this.user
        },this.transactionInstance)
    }
}