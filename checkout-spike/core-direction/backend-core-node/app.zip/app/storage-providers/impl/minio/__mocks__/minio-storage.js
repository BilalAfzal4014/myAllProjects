const BaseStorage = require("../../base-storage-for-mocking");

module.exports = class MinioStorage extends BaseStorage {


};