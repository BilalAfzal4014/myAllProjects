const BaseStorage = require("../../base-storage-for-mocking");

module.exports = class S3Storage extends BaseStorage {

};