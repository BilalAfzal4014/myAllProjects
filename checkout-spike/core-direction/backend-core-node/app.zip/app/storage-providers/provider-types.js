module.exports = Object.freeze({
    AMAZON_S3: "AMAZON_S3",
    MINIO: "MINIO"
});