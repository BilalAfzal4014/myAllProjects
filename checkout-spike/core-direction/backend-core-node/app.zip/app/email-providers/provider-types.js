module.exports = Object.freeze({
    NODE_MAILER: "NODE_MAILER",
    SEND_GRID: "SEND_GRID"
});