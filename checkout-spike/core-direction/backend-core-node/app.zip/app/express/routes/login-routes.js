const router = require('express').Router();
const LoginModuleUseCase = require("../../usecases/auth/login/login-module-usecase");
const HttpResponseHandler = require("../../errors/handlers/http-error-response-handler");

router.post('/:type', (req, res) => {
    const interactor = new LoginModuleUseCase(req.params.type, req.body)
    interactor.login()
        .then((result) => {
            res.status(200).json(result);
        }).catch((error) => {
        return new HttpResponseHandler(res).handleError(error);
    });

});

module.exports = router;