const router = require('express').Router();


router.get('/health-check', (_, resp) => {
    resp.status(200).json("Core-Direction application is working");
});

module.exports = router;