const router = require('express').Router();
const RefreshTokenUseCase = require("../../usecases/auth/refresh-token/refresh-token-usecase");
const HttpResponseHandler = require("../../errors/handlers/http-error-response-handler");

router.post('/', (req, res) => {
    console.log('yasir.......')
    const interactor = new RefreshTokenUseCase(req.body)
    interactor.getJwtToken()
        .then((result) => {
            res.status(200).json(result);
        }).catch((error) => {
        return new HttpResponseHandler(res).handleError(error);
    });

});

module.exports = router;