const router = require("express").Router();
const baseRoutes = require("./base-routes");
const loginRoutes = require("./login-routes");
const forgotPasswordRoutes = require("./forgot-password-routes");
const signUpRoute = require("./signup-routes");
const refreshTokenRoute = require("./refresh-token-routes");

const setupRoutes = (app) => {
    router.use("/login", loginRoutes);
    router.use("/forgot-password", forgotPasswordRoutes);
    router.use("/signup", signUpRoute);
    router.use("/refresh-token", refreshTokenRoute);
    app.use("/", baseRoutes);
    app.use("/v1", router);
};

module.exports = {
    setupRoutes,
};
