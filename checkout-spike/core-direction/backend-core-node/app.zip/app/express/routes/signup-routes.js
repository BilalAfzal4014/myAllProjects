const router = require('express').Router();
const RegisterModuleUseCase = require("../../usecases/auth/register/register-module-usecase");
const HttpResponseHandler = require("../../errors/handlers/http-error-response-handler");
router.post('/', (req, res) => {
   const interactor = new RegisterModuleUseCase(req.body);
   interactor.register()
       .then((data)=>{
           res.status(200).json({
               message:' Please check your email to confirm'
           });
       }).catch((error)=>{
      return new HttpResponseHandler(res).handleError(error);
   })

});

module.exports = router;