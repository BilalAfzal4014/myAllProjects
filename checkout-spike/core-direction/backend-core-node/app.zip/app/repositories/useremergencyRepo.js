module.exports = class UseremergencyRepo{
      
    }