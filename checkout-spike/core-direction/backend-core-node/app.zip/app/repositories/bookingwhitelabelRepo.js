module.exports = class BookingwhitelabelRepo{
      
    }