module.exports = class GmfActionsRepo{
      
    }