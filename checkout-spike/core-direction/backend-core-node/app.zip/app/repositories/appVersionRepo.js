module.exports = class AppVersionRepo{
      
    }