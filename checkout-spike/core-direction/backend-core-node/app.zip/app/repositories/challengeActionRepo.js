module.exports = class ChallengeActionRepo{
      
    }