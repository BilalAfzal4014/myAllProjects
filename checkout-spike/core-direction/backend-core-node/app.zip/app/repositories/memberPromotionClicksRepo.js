module.exports = class MemberPromotionClicksRepo{
      
    }