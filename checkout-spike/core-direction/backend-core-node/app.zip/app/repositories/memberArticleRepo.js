module.exports = class MemberArticleRepo{
      
    }