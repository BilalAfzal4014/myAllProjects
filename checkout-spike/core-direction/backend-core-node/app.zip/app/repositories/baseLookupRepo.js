module.exports = class BaseLookupRepo{
      
    }