module.exports = class ProfileKeyArticlesRepo{
      
    }