module.exports = class CorporateKeyPackageRepo{
      
    }