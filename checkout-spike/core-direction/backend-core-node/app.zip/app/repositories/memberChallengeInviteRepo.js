module.exports = class MemberChallengeInviteRepo{
      
    }