module.exports = class MemberMeasurementRepo{
      
    }