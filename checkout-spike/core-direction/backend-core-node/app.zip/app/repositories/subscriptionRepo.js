module.exports = class SubscriptionRepo{
      
    }