module.exports = class MemberBillingDetailRepo{
      
    }