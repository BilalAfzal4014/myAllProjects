module.exports = class ConfigurationsRepo{
      
    }