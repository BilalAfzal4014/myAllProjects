module.exports = class WorkoutExerciseRepo{
      
    }