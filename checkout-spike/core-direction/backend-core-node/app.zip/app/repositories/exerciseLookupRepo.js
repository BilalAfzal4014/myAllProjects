module.exports = class ExerciseLookupRepo{
      
    }