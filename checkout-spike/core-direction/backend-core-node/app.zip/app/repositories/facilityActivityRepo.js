module.exports = class FacilityActivityRepo{
      
    }