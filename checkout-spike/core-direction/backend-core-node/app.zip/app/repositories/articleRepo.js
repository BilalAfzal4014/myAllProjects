module.exports = class ArticleRepo{
      
    }