module.exports = class EmailRepo{
      
    }