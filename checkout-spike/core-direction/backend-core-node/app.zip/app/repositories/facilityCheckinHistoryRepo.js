module.exports = class FacilityCheckinHistoryRepo{
      
    }