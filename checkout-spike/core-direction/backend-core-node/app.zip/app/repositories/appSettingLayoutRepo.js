module.exports = class AppSettingLayoutRepo{
      
    }