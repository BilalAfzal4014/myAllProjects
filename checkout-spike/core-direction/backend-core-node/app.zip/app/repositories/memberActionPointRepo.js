module.exports = class MemberActionPointRepo{
      
    }