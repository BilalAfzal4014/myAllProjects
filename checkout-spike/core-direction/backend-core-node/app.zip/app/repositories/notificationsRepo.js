module.exports = class NotificationsRepo{
      
    }