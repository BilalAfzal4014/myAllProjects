module.exports = class MemberInvitationRepo{
      
    }