module.exports = class MemberScheduleTimelogRepo{
      
    }