module.exports = class UserAwardPointRepo{
      
    }