module.exports = class VwMembersRepo{
      
    }