module.exports = class ActivitySchedulePackageRepo{
      
    }