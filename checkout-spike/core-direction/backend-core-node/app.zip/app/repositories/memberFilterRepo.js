module.exports = class MemberFilterRepo{
      
    }