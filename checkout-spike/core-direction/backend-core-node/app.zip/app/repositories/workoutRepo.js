module.exports = class WorkoutRepo{
      
    }