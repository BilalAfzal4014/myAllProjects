module.exports = class UsergiftsRepo{
      
    }