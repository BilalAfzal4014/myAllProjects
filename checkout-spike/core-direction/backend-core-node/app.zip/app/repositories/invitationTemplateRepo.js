module.exports = class InvitationTemplateRepo{
      
    }