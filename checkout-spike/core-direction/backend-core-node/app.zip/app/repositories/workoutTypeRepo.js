module.exports = class WorkoutTypeRepo{
      
    }