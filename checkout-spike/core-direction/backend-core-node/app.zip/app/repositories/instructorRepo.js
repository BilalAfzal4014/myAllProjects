module.exports = class InstructorRepo{
      
    }