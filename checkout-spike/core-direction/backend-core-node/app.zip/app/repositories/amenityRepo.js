module.exports = class AmenityRepo{
      
    }