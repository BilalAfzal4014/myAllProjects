module.exports = class LayoutSectionsRepo{
      
    }