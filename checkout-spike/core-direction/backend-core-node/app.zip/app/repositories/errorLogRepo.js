module.exports = class ErrorLogRepo{
      
    }