module.exports = class BookingwhitelabelUserRepo{
      
    }