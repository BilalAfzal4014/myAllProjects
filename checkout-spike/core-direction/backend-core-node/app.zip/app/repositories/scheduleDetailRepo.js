module.exports = class ScheduleDetailRepo{
      
    }