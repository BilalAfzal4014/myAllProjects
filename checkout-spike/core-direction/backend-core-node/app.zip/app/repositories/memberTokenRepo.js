module.exports = class MemberTokenRepo{
      
    }