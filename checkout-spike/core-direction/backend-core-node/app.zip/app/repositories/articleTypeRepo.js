module.exports = class ArticleTypeRepo{
      
    }