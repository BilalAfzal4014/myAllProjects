module.exports = class PromotionsRepo{
      
    }