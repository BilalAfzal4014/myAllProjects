module.exports = class ActivityScheduleRepo{
      
    }