const BaseRepo = require("./baseRepo");
const MemberPackageModel = require("../models/memberPackageModel");

module.exports = class MemberPackageRepo extends BaseRepo {


    static save(MemberPackageData, transaction = null) {
        if (!MemberPackageData.id) {
            return MemberPackageModel.query(transaction).insertAndFetch(MemberPackageData);
        } else {
            return MemberPackageModel.query(transaction).updateAndFetchById(MemberPackageData.id, MemberPackageData);
        }
    }
}