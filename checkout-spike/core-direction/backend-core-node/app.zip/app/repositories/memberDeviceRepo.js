module.exports = class MemberDeviceRepo{
      
    }