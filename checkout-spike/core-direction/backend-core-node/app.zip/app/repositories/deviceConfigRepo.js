module.exports = class DeviceConfigRepo{
      
    }