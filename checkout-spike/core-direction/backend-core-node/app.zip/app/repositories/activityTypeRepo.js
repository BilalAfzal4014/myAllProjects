module.exports = class ActivityTypeRepo{
      
    }