module.exports = class AclClassesRepo{
      
    }