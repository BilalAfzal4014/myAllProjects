module.exports = class FacilityGalleryRepo{
      
    }