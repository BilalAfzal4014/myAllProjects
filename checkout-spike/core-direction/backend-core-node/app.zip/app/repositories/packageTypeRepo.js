module.exports = class PackageTypeRepo{
      
    }