module.exports = class ExerciseImageRepo{
      
    }