module.exports = class UserBankInfoRepo{
      
    }