module.exports = class MemberBillingRepo{
      
    }