module.exports = class AppSettingRepo{
      
    }