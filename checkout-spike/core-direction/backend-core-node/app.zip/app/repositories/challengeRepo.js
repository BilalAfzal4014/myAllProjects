module.exports = class ChallengeRepo{
      
    }