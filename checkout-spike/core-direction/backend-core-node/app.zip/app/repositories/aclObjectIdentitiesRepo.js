module.exports = class AclObjectIdentitiesRepo{
      
    }