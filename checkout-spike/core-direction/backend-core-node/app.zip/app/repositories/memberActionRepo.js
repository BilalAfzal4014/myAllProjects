module.exports = class MemberActionRepo{
      
    }