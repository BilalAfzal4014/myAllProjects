module.exports = class ExerciseRepo{
      
    }