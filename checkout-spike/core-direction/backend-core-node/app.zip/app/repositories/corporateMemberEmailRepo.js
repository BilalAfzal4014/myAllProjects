module.exports = class CorporateMemberEmailRepo{
      
    }