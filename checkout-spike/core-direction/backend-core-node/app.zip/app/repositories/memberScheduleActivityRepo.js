module.exports = class MemberScheduleActivityRepo{
      
    }