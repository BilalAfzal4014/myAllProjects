module.exports = class CorporateDepartmentRepo{
      
    }