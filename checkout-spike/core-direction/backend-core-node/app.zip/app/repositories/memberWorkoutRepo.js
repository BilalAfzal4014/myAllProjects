module.exports = class MemberWorkoutRepo{
      
    }