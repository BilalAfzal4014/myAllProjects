module.exports = class AclEntriesRepo{
      
    }