module.exports = class FacilityPackageRepo{
      
    }