module.exports = class SectionsRepo{
      
    }