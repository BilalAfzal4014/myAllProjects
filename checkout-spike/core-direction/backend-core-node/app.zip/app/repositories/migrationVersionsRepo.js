module.exports = class MigrationVersionsRepo{
      
    }