module.exports = class ManualCheckinHistoryRepo{
      
    }