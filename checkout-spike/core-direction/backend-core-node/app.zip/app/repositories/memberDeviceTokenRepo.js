module.exports = class MemberDeviceTokenRepo{
      
    }