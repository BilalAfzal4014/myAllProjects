module.exports = class AclObjectIdentityAncestorsRepo{
      
    }