module.exports = class KeyProfileGroupRepo{
      
    }