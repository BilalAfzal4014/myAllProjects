module.exports = class FacilityAmenityRepo{
      
    }