const validationRulesForUser = require("./validation-rules-user.json");
const validationRulesForMemberKey = require("./validation-rules-member-key.json");

module.exports = class RegisterModuleEntity {
    getValidationRulesForUser = () => validationRulesForUser;

    getUserProvidedFieldsForUser = () => (['email', 'password','phone_number']);

    getFieldsForUniquenessForUser = () => ([]);


    getValidationRulesForMemberKey = () => validationRulesForMemberKey;

    getUserProvidedFieldsForMemberKey = () => (['key_id']);

    getFieldsForUniquenessForMemberKey = () => ([]);


}