module.exports = class Base64Helper {
    static base64Encode(str) {
        return Buffer.from(str).toString('base64');
    }

    static base64Decode(base64EncodedStr) {
        return Buffer.from(base64EncodedStr, "base64").toString();
    }
}