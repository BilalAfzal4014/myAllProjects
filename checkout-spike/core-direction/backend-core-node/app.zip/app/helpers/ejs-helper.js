const path = require("path")
const ejs = require("ejs");

module.exports = class EjsHelper {
    static renderFileFromGivenPath(path, data) {
        const pathUptoViewsFolder = EjsHelper.getViewsAbsolutePath();
        return new Promise((resolve, reject) => {
            ejs.renderFile(pathUptoViewsFolder + path, data, function (error, renderedHtmlFile) {
                if (error)
                    return reject(error);
                resolve(renderedHtmlFile);
            });
        });
    }

    static getViewsAbsolutePath() {
        return path.join(__dirname, '../views') + "/";
    }
}