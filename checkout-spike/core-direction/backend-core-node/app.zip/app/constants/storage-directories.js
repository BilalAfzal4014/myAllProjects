module.exports = Object.freeze({
    CATEGORIES: "category",
    CATEGORY_TEMPLATE: "category_template",
    PRODUCT_VARIANT: "product_variants",
    PRODUCT: "product",
    PRODUCT_DESCRIPTION: "product_description",
});