module.exports = Object.freeze({
    PACKAGE: "Package",
    COREPASS: "CorePass",
});