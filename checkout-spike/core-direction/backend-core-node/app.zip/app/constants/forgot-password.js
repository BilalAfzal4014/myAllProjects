module.exports = Object.freeze({
    EMAIL_SUBJECT: "Core Direction! here is your reset password link",
});