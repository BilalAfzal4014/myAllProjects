module.exports = Object.freeze({
    MEMBER: "Member",
});