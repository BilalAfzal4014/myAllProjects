module.exports = Object.freeze({
    ACTIVE: "active",
});