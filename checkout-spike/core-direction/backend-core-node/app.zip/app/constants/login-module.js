module.exports = Object.freeze({
    CREDENTIALS: "CREDENTIALS",
    SOCIAL: "SOCIAL",
});