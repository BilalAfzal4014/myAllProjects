module.exports = class ArticleModel{
        static get tableName() {
            return "article";
        }
    }