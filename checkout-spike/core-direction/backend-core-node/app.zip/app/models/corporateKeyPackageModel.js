module.exports = class CorporateKeyPackageModel{
        static get tableName() {
            return "corporate_key_package";
        }
    }