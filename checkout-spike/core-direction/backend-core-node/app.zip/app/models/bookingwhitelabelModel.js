module.exports = class BookingwhitelabelModel{
        static get tableName() {
            return "BookingWhiteLabel";
        }
    }