module.exports = class MemberDeviceTokenModel{
        static get tableName() {
            return "member_device_token";
        }
    }