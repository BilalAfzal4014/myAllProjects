module.exports = class MemberActionModel{
        static get tableName() {
            return "member_action";
        }
    }