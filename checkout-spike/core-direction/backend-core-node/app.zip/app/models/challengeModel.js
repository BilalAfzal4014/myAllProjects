module.exports = class ChallengeModel{
        static get tableName() {
            return "challenge";
        }
    }