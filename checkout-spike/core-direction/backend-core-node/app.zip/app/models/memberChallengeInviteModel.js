module.exports = class MemberChallengeInviteModel{
        static get tableName() {
            return "member_challenge_invite";
        }
    }