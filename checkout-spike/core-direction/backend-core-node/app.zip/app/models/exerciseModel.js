module.exports = class ExerciseModel{
        static get tableName() {
            return "exercise";
        }
    }