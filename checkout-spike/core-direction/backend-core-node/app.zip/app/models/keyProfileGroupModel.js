module.exports = class KeyProfileGroupModel{
        static get tableName() {
            return "key_profile_group";
        }
    }