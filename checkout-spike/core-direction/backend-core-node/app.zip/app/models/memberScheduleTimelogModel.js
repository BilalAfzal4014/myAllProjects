module.exports = class MemberScheduleTimelogModel{
        static get tableName() {
            return "member_schedule_timelog";
        }
    }