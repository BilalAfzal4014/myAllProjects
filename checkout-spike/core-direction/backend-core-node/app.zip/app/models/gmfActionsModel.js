module.exports = class GmfActionsModel{
        static get tableName() {
            return "gmf_actions";
        }
    }