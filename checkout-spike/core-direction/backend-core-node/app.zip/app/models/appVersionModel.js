module.exports = class AppVersionModel{
        static get tableName() {
            return "app_version";
        }
    }