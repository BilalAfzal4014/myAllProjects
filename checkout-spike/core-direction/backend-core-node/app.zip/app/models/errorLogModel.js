module.exports = class ErrorLogModel{
        static get tableName() {
            return "error_log";
        }
    }