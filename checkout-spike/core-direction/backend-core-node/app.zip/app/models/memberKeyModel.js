const BaseModel = require("./baseModel");
const {knex} = require("../databases/sql-connection");

module.exports = class MemberKeyModel extends BaseModel {
    static get tableName() {
        return "member_key";
    }

    $beforeInsert() {
        delete this.created_date;
        delete this.updated_date;

    }

    $beforeUpdate() {
        delete this.updated_date;
    }
}