module.exports = class FacilityPackageModel{
        static get tableName() {
            return "facility_package";
        }
    }