module.exports = class ActivityScheduleModel{
        static get tableName() {
            return "activity_schedule";
        }
    }