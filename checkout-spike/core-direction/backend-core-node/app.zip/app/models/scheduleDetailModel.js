module.exports = class ScheduleDetailModel{
        static get tableName() {
            return "schedule_detail";
        }
    }