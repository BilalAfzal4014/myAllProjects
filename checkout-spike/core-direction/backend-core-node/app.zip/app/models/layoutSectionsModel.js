module.exports = class LayoutSectionsModel{
        static get tableName() {
            return "layout_sections";
        }
    }