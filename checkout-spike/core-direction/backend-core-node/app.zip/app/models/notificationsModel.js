module.exports = class NotificationsModel{
        static get tableName() {
            return "notifications";
        }
    }