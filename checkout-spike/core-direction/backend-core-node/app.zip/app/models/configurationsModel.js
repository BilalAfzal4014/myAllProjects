module.exports = class ConfigurationsModel{
        static get tableName() {
            return "configurations";
        }
    }