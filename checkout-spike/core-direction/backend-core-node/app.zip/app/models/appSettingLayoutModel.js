module.exports = class AppSettingLayoutModel{
        static get tableName() {
            return "app_setting_layout";
        }
    }