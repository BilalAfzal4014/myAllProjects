module.exports = class MemberFilterModel{
        static get tableName() {
            return "member_filter";
        }
    }