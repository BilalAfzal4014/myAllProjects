module.exports = class MigrationVersionsModel{
        static get tableName() {
            return "migration_versions";
        }
    }