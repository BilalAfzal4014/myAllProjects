module.exports = class ExerciseLookupModel{
        static get tableName() {
            return "exercise_lookup";
        }
    }