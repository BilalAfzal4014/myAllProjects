module.exports = class AppSettingModel{
        static get tableName() {
            return "app_setting";
        }
    }