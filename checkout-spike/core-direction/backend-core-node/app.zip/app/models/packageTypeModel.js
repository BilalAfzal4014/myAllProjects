module.exports = class PackageTypeModel{
        static get tableName() {
            return "package_type";
        }
    }