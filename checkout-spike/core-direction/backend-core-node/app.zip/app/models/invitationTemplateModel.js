module.exports = class InvitationTemplateModel{
        static get tableName() {
            return "invitation_template";
        }
    }