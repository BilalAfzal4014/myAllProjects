module.exports = class ActivityTypeModel{
        static get tableName() {
            return "activity_type";
        }
    }