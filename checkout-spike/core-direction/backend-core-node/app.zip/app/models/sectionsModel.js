module.exports = class SectionsModel{
        static get tableName() {
            return "sections";
        }
    }