module.exports = class WorkoutTypeModel{
        static get tableName() {
            return "workout_type";
        }
    }