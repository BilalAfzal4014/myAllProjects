module.exports = class CorporateDepartmentModel{
        static get tableName() {
            return "corporate_department";
        }
    }