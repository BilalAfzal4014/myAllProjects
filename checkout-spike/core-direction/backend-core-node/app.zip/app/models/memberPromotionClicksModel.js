module.exports = class MemberPromotionClicksModel{
        static get tableName() {
            return "member_promotion_clicks";
        }
    }