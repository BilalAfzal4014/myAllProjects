module.exports = class MemberArticleModel{
        static get tableName() {
            return "member_article";
        }
    }