module.exports = class BaseLookupModel{
        static get tableName() {
            return "base_lookup";
        }
    }