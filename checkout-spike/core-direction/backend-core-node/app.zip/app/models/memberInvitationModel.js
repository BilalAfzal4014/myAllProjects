module.exports = class MemberInvitationModel{
        static get tableName() {
            return "member_invitation";
        }
    }