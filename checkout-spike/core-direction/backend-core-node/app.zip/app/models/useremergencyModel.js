module.exports = class UseremergencyModel{
        static get tableName() {
            return "UserEmergency";
        }
    }