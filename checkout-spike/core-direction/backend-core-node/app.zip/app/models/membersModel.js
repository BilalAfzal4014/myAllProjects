module.exports = class MembersModel{
        static get tableName() {
            return "members";
        }
    }