module.exports = class BookingwhitelabelUserModel{
        static get tableName() {
            return "bookingwhitelabel_user";
        }
    }