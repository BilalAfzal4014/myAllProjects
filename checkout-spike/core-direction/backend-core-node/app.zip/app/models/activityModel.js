module.exports = class ActivityModel{
        static get tableName() {
            return "activity";
        }
    }