module.exports = class FacilityActivityModel{
        static get tableName() {
            return "facility_activity";
        }
    }