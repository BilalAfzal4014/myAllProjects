module.exports = class CorporateMemberEmailModel{
        static get tableName() {
            return "corporate_member_email";
        }
    }