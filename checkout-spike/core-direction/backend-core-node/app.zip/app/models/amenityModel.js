module.exports = class AmenityModel{
        static get tableName() {
            return "amenity";
        }
    }