module.exports = class UserAwardPointModel{
        static get tableName() {
            return "user_award_point";
        }
    }