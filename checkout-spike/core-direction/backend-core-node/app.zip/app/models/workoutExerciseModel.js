module.exports = class WorkoutExerciseModel{
        static get tableName() {
            return "workout_exercise";
        }
    }