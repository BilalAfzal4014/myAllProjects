module.exports = class MemberActionPointModel{
        static get tableName() {
            return "member_action_point";
        }
    }