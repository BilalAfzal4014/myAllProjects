module.exports = class PromotionsModel{
        static get tableName() {
            return "promotions";
        }
    }