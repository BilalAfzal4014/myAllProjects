module.exports = class LayoutModel{
        static get tableName() {
            return "layout";
        }
    }