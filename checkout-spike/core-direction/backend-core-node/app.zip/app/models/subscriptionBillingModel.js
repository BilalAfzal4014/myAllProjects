module.exports = class SubscriptionBillingModel{
        static get tableName() {
            return "subscription_billing";
        }
    }