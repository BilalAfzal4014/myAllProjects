module.exports = class FacilityAmenityModel{
        static get tableName() {
            return "facility_amenity";
        }
    }