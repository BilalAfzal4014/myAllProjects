module.exports = class UserBankInfoModel{
        static get tableName() {
            return "user_bank_info";
        }
    }