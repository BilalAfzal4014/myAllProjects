module.exports = class SubscriptionModel{
        static get tableName() {
            return "subscription";
        }
    }