module.exports = class MemberTokenModel{
        static get tableName() {
            return "member_token";
        }
    }