module.exports = class ActionsModel{
        static get tableName() {
            return "actions";
        }
    }