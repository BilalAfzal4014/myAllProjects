module.exports = class MemberDeviceModel{
        static get tableName() {
            return "member_device";
        }
    }