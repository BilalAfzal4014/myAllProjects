module.exports = class AclClassesModel{
        static get tableName() {
            return "acl_classes";
        }
    }