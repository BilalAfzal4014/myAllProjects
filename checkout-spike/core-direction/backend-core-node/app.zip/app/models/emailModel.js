module.exports = class EmailModel{
        static get tableName() {
            return "email";
        }
    }