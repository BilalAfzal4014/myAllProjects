module.exports = class ProfileKeyWorkoutsModel{
        static get tableName() {
            return "profile_key_workouts";
        }
    }