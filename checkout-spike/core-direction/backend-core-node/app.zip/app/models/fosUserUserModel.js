const BaseModel = require("./baseModel");
const {knex} = require("../databases/sql-connection");

module.exports = class FosUserUserModel extends BaseModel {
    static get tableName() {
        return "fos_user_user";
    }

    $beforeInsert() {
        delete this.created_date;
        delete this.updated_date;

        this.created_at = new Date();
        this.updated_at = new Date();
    }

    $beforeUpdate() {
        delete this.updated_date;
        this.updated_at = new Date();
    }
}