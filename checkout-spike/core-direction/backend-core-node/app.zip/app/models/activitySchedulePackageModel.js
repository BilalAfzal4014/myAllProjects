module.exports = class ActivitySchedulePackageModel{
        static get tableName() {
            return "activity_schedule_package";
        }
    }