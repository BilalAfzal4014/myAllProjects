module.exports = class FacilityCheckinHistoryModel{
        static get tableName() {
            return "facility_checkin_history";
        }
    }