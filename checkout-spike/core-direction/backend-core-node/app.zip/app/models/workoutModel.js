module.exports = class WorkoutModel{
        static get tableName() {
            return "workout";
        }
    }