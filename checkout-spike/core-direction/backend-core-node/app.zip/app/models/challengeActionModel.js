module.exports = class ChallengeActionModel{
        static get tableName() {
            return "challenge_action";
        }
    }