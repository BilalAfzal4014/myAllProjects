module.exports = class MemberMeasurementModel{
        static get tableName() {
            return "member_measurement";
        }
    }