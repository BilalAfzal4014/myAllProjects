module.exports = class WorkoutLevelModel{
        static get tableName() {
            return "workout_level";
        }
    }