module.exports = class ProfileKeyArticlesModel{
        static get tableName() {
            return "profile_key_articles";
        }
    }