module.exports = class ProfileKeyModel{
        static get tableName() {
            return "profile_key";
        }
    }