module.exports = class MemberBillingDetailModel{
        static get tableName() {
            return "member_billing_detail";
        }
    }