module.exports = class FacilityGalleryModel{
        static get tableName() {
            return "facility_gallery";
        }
    }