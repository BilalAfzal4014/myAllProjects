module.exports = class AclEntriesModel{
        static get tableName() {
            return "acl_entries";
        }
    }