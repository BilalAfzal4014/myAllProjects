module.exports = class UsergiftsModel{
        static get tableName() {
            return "UserGifts";
        }
    }