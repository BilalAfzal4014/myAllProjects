module.exports = class UserDocumentsModel{
        static get tableName() {
            return "user_documents";
        }
    }