module.exports = class ManualCheckinHistoryModel{
        static get tableName() {
            return "manual_checkin_history";
        }
    }