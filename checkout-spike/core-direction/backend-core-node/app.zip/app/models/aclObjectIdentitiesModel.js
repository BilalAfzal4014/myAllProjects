module.exports = class AclObjectIdentitiesModel{
        static get tableName() {
            return "acl_object_identities";
        }
    }