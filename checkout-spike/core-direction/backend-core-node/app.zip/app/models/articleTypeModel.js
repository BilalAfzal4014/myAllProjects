module.exports = class ArticleTypeModel{
        static get tableName() {
            return "article_type";
        }
    }