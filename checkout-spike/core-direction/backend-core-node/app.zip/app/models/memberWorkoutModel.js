module.exports = class MemberWorkoutModel{
        static get tableName() {
            return "member_workout";
        }
    }