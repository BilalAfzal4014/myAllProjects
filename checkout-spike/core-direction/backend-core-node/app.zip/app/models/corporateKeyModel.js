const BaseModel = require("./baseModel");
const {knex} = require("../databases/sql-connection");

module.exports = class CorporateKeyModel extends BaseModel{
    static get tableName() {
        return "corporate_key";
    }

    $beforeInsert() {
        delete this.created_date;
        delete this.updated_date;

    }

    $beforeUpdate() {
        delete this.updated_date;
    }

    static fetchActiveNonDefaultKeyWithCompanyKey(company_key) {
        let now = new Date().toLocaleString();
        let notInclude= 'Default';
        const query = `
            SELECT * FROM corporate_key
             WHERE company_key LIKE :company_key 
             AND validate_date >= now()
             AND is_active = 1
            AND \`type\` != :notInclude
        `;



            return knex.raw(query, {
                company_key,
                now,
                notInclude
            }).then(([result]) => {
                return result[0] ? result[0] : null;
            });

    }
}