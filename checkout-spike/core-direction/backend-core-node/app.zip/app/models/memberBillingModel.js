module.exports = class MemberBillingModel{
        static get tableName() {
            return "member_billing";
        }
    }