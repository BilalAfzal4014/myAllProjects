const BaseModel = require("./baseModel");
const {knex} = require("../databases/sql-connection");

module.exports = class RefreshTokensModel extends BaseModel {
    static get tableName() {
        return "refresh_tokens";
    }

    $beforeInsert() {
        delete this.created_date;
        delete this.updated_date;
    }

    $beforeUpdate() {
        delete this.updated_date;
    }

    static findUserAgainstRefreshToken(refresh_token) {
        const query = `
            select refresh_tokens.*
            from refresh_tokens where refresh_tokens.refresh_token = :refresh_token`;

        return knex.raw(query, {
            refresh_token
        }).then(([result]) => {
            return result[0] ? result[0] : null;
        });
    }
}