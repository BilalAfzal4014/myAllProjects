module.exports = class MemberScheduleActivityModel{
        static get tableName() {
            return "member_schedule_activity";
        }
    }