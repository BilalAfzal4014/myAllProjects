module.exports = class VwMembersModel{
        static get tableName() {
            return "vw_members";
        }
    }