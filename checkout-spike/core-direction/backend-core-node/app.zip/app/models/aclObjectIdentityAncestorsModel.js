module.exports = class AclObjectIdentityAncestorsModel{
        static get tableName() {
            return "acl_object_identity_ancestors";
        }
    }