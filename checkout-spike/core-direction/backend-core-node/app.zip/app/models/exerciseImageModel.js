module.exports = class ExerciseImageModel{
        static get tableName() {
            return "exercise_image";
        }
    }