module.exports = class AclSecurityIdentitiesModel{
        static get tableName() {
            return "acl_security_identities";
        }
    }