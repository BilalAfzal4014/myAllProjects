module.exports = class DeviceConfigModel{
        static get tableName() {
            return "device_config";
        }
    }