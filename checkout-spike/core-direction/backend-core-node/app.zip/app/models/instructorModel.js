module.exports = class InstructorModel{
        static get tableName() {
            return "instructor";
        }
    }